// aws_search.js - for AWS Cloud Search
